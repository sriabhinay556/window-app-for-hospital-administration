import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JRadioButton;

public class OEFrame {

	 JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OEFrame window = new OEFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OEFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(135, 206, 250));
		frame.setBounds(100, 100, 517, 331);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("----------------------------------------------------------------------------------------------------------------------------------");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(-17, 10, 569, 13);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblInpatients = new JLabel("IN-Patients");
		lblInpatients.setForeground(Color.RED);
		lblInpatients.setFont(new Font("Segoe UI", Font.BOLD, 22));
		lblInpatients.setBounds(34, 33, 314, 30);
		frame.getContentPane().add(lblInpatients);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("----------------------------------------------------------------------------------------------------------------------------------");
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1_2.setBounds(-39, 66, 569, 13);
		frame.getContentPane().add(lblNewLabel_1_1_2);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Operations");
		rdbtnNewRadioButton.setBackground(new Color(175, 238, 238));
		rdbtnNewRadioButton.setFont(new Font("Raavi", Font.BOLD, 18));
		rdbtnNewRadioButton.setBounds(39, 85, 161, 30);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnEmergency = new JRadioButton("Emergency");
		rdbtnEmergency.setBackground(new Color(175, 238, 238));
		rdbtnEmergency.setFont(new Font("Raavi", Font.BOLD, 18));
		rdbtnEmergency.setBounds(39, 126, 161, 30);
		frame.getContentPane().add(rdbtnEmergency);
		
		JLabel lblNewLabel_1_1_2_1 = new JLabel("----------------------------------------------------------------------------------------------------------------------------------");
		lblNewLabel_1_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1_2_1.setBounds(-17, 165, 569, 13);
		frame.getContentPane().add(lblNewLabel_1_1_2_1);
		
		JButton btnNewButton = new JButton("LogOut");
		btnNewButton.setFont(new Font("Raavi", Font.BOLD, 14));
		btnNewButton.setBounds(10, 264, 85, 21);
		frame.getContentPane().add(btnNewButton);
		rdbtnNewRadioButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				OpeDetailsFrame f9 = new OpeDetailsFrame();
				f9.frame.setVisible(true);
				try {
					File file = new File("D://CourseProject/f1.txt");
					FileWriter fw = new FileWriter(file,true);
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write("For : Operation Case");  bw.write("\r\n");
					bw.close();
					fw.close();
				}catch(Exception e1) {}
			}
		});
		rdbtnEmergency.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					File file = new File("D://CourseProject/f1.txt");
					FileWriter fw = new FileWriter(file,true);
					BufferedWriter bw = new BufferedWriter(fw);
					bw.write("For : Emergency Case");  bw.write("\r\n");
					bw.close();
					fw.close();
				}catch(Exception e1) {}
				
				
				EmeFrame f10 = new EmeFrame();
				f10.frame.setVisible(true);
			}
		});

		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			LoginFrame1 f1 = new LoginFrame1();
			f1.frame.setVisible(true);
			}
		});
	}
}
