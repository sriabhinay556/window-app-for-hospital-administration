import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.io.*;

public class ODetailsFrame {


	 JFrame frame;
	 JTextField textField;
	 JTextField textField_1;
	 JTextField textField_2;
	 JTextField textField_3;
	 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ODetailsFrame window = new ODetailsFrame();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ODetailsFrame() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(135, 206, 235));
		frame.getContentPane().setForeground(new Color(135, 206, 235));
		frame.setBounds(100, 100, 345, 527);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1_1 = new JLabel("-----------------------------------------------------------------");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(-94, 10, 569, 13);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblIpRegistrationDetails = new JLabel("OP REGISTRATION DETAILS");
		lblIpRegistrationDetails.setForeground(Color.RED);
		lblIpRegistrationDetails.setFont(new Font("Segoe UI", Font.BOLD, 22));
		lblIpRegistrationDetails.setBounds(10, 33, 314, 30);
		frame.getContentPane().add(lblIpRegistrationDetails);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("-----------------------------------------------------------------");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1_1.setBounds(-126, 73, 569, 13);
		frame.getContentPane().add(lblNewLabel_1_1_1);
		
		textField = new JTextField();
		textField.setText("Name");
		textField.setSelectionColor(new Color(175, 238, 238));
		textField.setSelectedTextColor(new Color(175, 238, 238));
		textField.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		textField.setColumns(10);
		textField.setBackground(new Color(175, 238, 238));
		textField.setBounds(10, 96, 170, 28);
		frame.getContentPane().add(textField);
		
		textField_1 = new JTextField();
		textField_1.setText("Age");
		textField_1.setSelectionColor(new Color(175, 238, 238));
		textField_1.setSelectedTextColor(new Color(175, 238, 238));
		textField_1.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		textField_1.setColumns(10);
		textField_1.setBackground(new Color(175, 238, 238));
		textField_1.setBounds(10, 139, 67, 28);
		frame.getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setText("Date-of-birth");
		textField_2.setSelectionColor(new Color(175, 238, 238));
		textField_2.setSelectedTextColor(new Color(175, 238, 238));
		textField_2.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		textField_2.setColumns(10);
		textField_2.setBackground(new Color(175, 238, 238));
		textField_2.setBounds(87, 139, 108, 28);
		frame.getContentPane().add(textField_2);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 16));
		rdbtnNewRadioButton.setBackground(new Color(175, 238, 238));
		rdbtnNewRadioButton.setBounds(10, 190, 103, 21);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnFemale = new JRadioButton("Female");
		rdbtnFemale.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 16));
		rdbtnFemale.setBackground(new Color(175, 238, 238));
		rdbtnFemale.setBounds(136, 190, 103, 21);
		frame.getContentPane().add(rdbtnFemale);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnNewRadioButton);
		bg.add(rdbtnFemale);
		
		textField_3 = new JTextField();
		textField_3.setText("+91-Contact Number");
		textField_3.setSelectionColor(new Color(175, 238, 238));
		textField_3.setSelectedTextColor(new Color(175, 238, 238));
		textField_3.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
		textField_3.setColumns(10);
		textField_3.setBackground(new Color(175, 238, 238));
		textField_3.setBounds(10, 227, 170, 28);
		frame.getContentPane().add(textField_3);
		
		JLabel lblNewLabel = new JLabel("Address Details :");
		lblNewLabel.setFont(new Font("MS Reference Sans Serif", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 262, 170, 15);
		frame.getContentPane().add(lblNewLabel);
		
		JTextArea textArea = new JTextArea();
		textArea.setBackground(new Color(175, 238, 238));
		textArea.setBounds(10, 287, 248, 88);
		frame.getContentPane().add(textArea);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setFont(new Font("Raavi", Font.BOLD, 18));
		btnNewButton.setBounds(99, 408, 108, 21);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("LogOut");
		btnNewButton_1.setFont(new Font("Raavi", Font.BOLD, 14));
		btnNewButton_1.setBounds(10, 460, 85, 21);
		frame.getContentPane().add(btnNewButton_1);

		
rdbtnNewRadioButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
			
				try {
					File file = new File("D://CourseProject/f1.txt");
					FileWriter fr= new FileWriter(file, true);
					BufferedWriter bw = new BufferedWriter(fr);

					// Below constructor argument decides whether to append or override
					
					bw.write("Gender  : Male");
					bw.write("\r\n");
					bw.close();
					fr.close();
				} catch (IOException e1) {
				} 
			}
		});

	
		rdbtnFemale.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {

					File file = new File("D://CourseProject/f1.txt");
					FileWriter fw = new FileWriter(file,true);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write("Gender : Female");
				bw.write("\r\n");
				bw.close();
				fw.close();
				}
				catch(Exception e1) {}
			}	
		});
		
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			
				try {
					File file = new File("D://CourseProject/f1.txt");
					FileWriter fw = new FileWriter(file,true);
					BufferedWriter bw = new BufferedWriter(fw);
					
				String n = textField.getText();
				bw.write("Name : ");	bw.write(n);	bw.write("\r\n");
				
				String a = textField_1.getText();
				bw.write("Age : "); 	bw.write(a); 	bw.write("\r\n");
				
				String dob = textField_2.getText();
				bw.write("D-O-B : "); bw.write(dob); 	bw.write("\r\n");
				
				bw.close();
				fw.close();
				
				}	
			
				catch(Exception e9) {}
				CDFrame f5 = new CDFrame();
				f5.frame.setVisible(true);
				
			}
			});

		btnNewButton_1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			LoginFrame1 f1 = new LoginFrame1();
			f1.frame.setVisible(true);
			}
		});
	
}

}